#include <iostream>
using namespace std;
int main() {
  int bin,num,dec,i;
  cout<<


}
